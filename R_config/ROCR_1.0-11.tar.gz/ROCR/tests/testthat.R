library(testthat)
library(ROCR)

test_check("ROCR")
